install.packages("devtools"); library(devtools)
install_github("sdellicour/seraphim/unix_OS") # for Unix systems
install_github("sdellicour/seraphim/windows") # for Windows systems

library(seraphim)


# 1. Extracting spatio-temporal information embedded in trees

localTreesDirectory = "Extracted_trees"
allTrees = scan(file="RABV_gamma.trees", what="", sep="\n", quiet=TRUE)
burnIn = 1001
randomSampling = FALSE
nberOfTreesToSample = 100
mostRecentSamplingDatum = 2004.7
coordinateAttributeName = "location"

treeExtractions(localTreesDirectory, allTrees, burnIn, randomSampling,
				nberOfTreesToSample, mostRecentSamplingDatum, coordinateAttributeName)


# 2. Estimating dispersal statistics (optional)

nberOfExtractionFiles = 100
timeSlices = 100
onlyTipBranches = FALSE
showingPlots = FALSE
outputName = "RABV_raccoon"

spreadStatistics(localTreesDirectory, nberOfExtractionFiles, timeSlices, 
				 onlyTipBranches, showingPlots, outputName)


# 3. Preliminary analysis of the environmental raster

rast = raster("Elevation_raster.asc")
names(rast) = "elevation"
rast[rast[]<0] = 0
rast[] = rast[] + 1
plotRaster(rast, addAxes=T, addLegend=T)

nberOfExtractionFiles = 100
envVariables = list(rast)
pathModel = 2
resistances = c(TRUE)
avgResistances = c(TRUE)
fourCells = FALSE
nberOfRandomisations = 0
randomProcedure = 3
outputName = "RABV_elevation_least-cost"

spreadFactors(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances,
			  avgResistances, fourCells, nberOfRandomisations, randomProcedure, outputName)

tab = read.table("RABV_elevation_least-cost_linear_regression_results.txt", header=T)
LR_coefficients = tab[,"Univariate_LR_coefficients_elevation_R"]
	print(sum(LR_coefficients > 0))
Qs = tab[,"Univariate_LR_delta_R2_elevation_R"]
	print(sum(Qs > 0))


# 4. Assessing the statistical support with a randomisation procedure

nberOfRandomisations = 1

spreadFactors(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances,
			  avgResistances, fourCells, nberOfRandomisations, randomProcedure, outputName)

